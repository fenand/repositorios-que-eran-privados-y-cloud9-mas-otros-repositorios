
/**
 * Write a description of class Camion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Camion extends TheBigOnes
{
    /**
     * Constructor for objects of class Camion
     */
     public Camion(Marca marca, int antiguedad, int kilometraje, int peso)
    {
        super(marca, antiguedad, kilometraje, peso);
    }

    /**
     * An example of a method - replace this comment with your own
     */
    public int getPeso()
    {
        return super.getPeso();
    }
}
