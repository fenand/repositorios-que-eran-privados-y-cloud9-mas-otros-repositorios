
/**
 * Enumeration class Marca - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Marca
{
    FORD, FIAT, OPEL, CITROEN
}
