
/**
 * Write a description of class Coche here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Coche extends TheLittleOnes
{
    public Coche(Marca marca, int antiguedad, int kilometraje, int plazas)
    {
        super(marca, antiguedad, kilometraje, plazas);
    }
    
    /**
    * @Override
    */
    public int getplazas(){
        return super.getplazas();
    }
}
