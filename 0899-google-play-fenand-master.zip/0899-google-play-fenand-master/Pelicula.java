
/**
 * Clase encargada de crear peliculas
 *
 * @author (Fernando)
 * @version (29 de mayo de 2018)
 */
public class Pelicula extends ProductoMultimedia
{
    private int duracionEnMinutos;
    private int calidad;
    private static int CALIDAD_FULLHD = 1080;

    /**
     *Constructor de la clase peliculas
     *
     * @param identificador
     * @param ano
     * @param duracion
     * @param calidad
     */
    public Pelicula(String identificador, int ano, int duracion, int calidad)
    {
        super(identificador, ano);
        this.duracionEnMinutos = duracion;
        this.calidad = calidad;
    }

    /**
     *Metodo que devuelve la duracion de una pelicula
     *
     * @return La duracion en minutos
     */
    public int getDuracion()
    {
        return duracionEnMinutos;
    }

    /**
     *Metodo que devuelve la calidad de una pelicula
     *
     * @return La calidad en pixeles
     */
    public String getCalidad()
    {     
        String aDevolver = "HD";
        if (calidad == CALIDAD_FULLHD) {
            aDevolver = "FullHD";
        }
        return aDevolver;
    }

    /**
     * Metodo que devuelve el precio en funcion de la calidad
     * 
     * @return precio de la pelicula
     */
    @Override
    public double getPrecio()
    {
        double precio = 5;
        if (calidad == CALIDAD_FULLHD) {
            precio = 10;
        }

        if (getAño() < 2000) {
            precio = precio/2;
        }

        return precio;
    }

}
