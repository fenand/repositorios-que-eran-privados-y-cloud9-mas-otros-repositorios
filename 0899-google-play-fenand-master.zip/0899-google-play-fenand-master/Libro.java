
/**
 * Clase encargada de crear libros
 *
 * @author (Fernando)
 * @version (29 de mayo de 2018)
 */
public class Libro extends ProductoMultimedia {

    private int numeroDePaginas;
    private boolean ficcion;

    /**
     *Constructor de la clase libro
     *
     * @param identificador
     * @param ano
     * @param numeroPaginas
     * @param ficcion
     */
    public Libro(String identificador, int ano, int numeroPaginas, boolean ficcion) {
        super(identificador, ano);
        this.numeroDePaginas = numeroPaginas;
        this.ficcion = ficcion;
    }

    /**
     *Metodo para devolver el numero de paginas del libro
     *
     * @return numero de paginas del libro
     */
    public int getNumeroPaginas() {
        return numeroDePaginas;
    }

    /**
     *Metodo que devuelve si un libro es de ficcion o no
     *
     * @return Si es de ficcion(True) o no(False)
     */
    public boolean getFiccion() {
        return ficcion;
    }
    /**
     * Metodo para devolver el precio del libro
     * 
     * @return precio del libro
     */
    @Override
    public double getPrecio()
    {
        return (numeroDePaginas / 100) * (getAño() - 2010);
    }
}
