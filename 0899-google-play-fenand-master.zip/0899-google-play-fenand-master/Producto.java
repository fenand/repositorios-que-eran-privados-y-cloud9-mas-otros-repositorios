
/**
 * Clase producto engargada dar nombre a las aplicaciones y a los productos multimedia
 *
 * @author (Fernando)
 * @version (29 de mayo de 2018)
 */
public abstract class Producto
{
    private String nombre;
    private int numeroDeVecesQueSeHaVendido;

    /**
     * Constructor de la clase Producto 
     * 
     * @param nombre del producto
     */
    public Producto(String nombre)
    {
        this.nombre = nombre;
        numeroDeVecesQueSeHaVendido = 0;
    }

    /**
     * Metodo que devuelve el nombre del producto
     * 
     * @return nombre del producto
     */
    public String getNombre()
    {
        return nombre;
    }
    /**
     * Metodo para devolver el numeo de veces que se ha vendido el producto
     * 
     * @return numero de veces vendido el producto
     */
    public double getNumeroVecesVendido()
    {
        return numeroDeVecesQueSeHaVendido;
    }
    /**
     * Metodo para sumar ventas
     * 
     */
    public void vender()
    {
        numeroDeVecesQueSeHaVendido++;
    }
    /**
     * Metodo abstacto para devolver el precio del producto
     */
    public abstract double getPrecio();
}
