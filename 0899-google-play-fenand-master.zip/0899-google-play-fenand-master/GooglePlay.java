
import java.util.ArrayList;

/**
 * Clase encargada de crear googleplay
 *
 * @author (Fernando)
 * @version (29 de mayo de 2018)
 */
public class GooglePlay {

    private ArrayList<Usuario> usuarios;
    private ArrayList<Producto> productos;

    /**
     * Constructor de la clase Googleplay
     */
    public GooglePlay() {
        usuarios = new ArrayList<>();
        productos = new ArrayList<>();
    }

    /**
     *Metodo para añadir usuarios al arraylist
     *
     * @param usuario para añadir
     */
    public void addUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    /**
     *Metodo para añadir productos al arraylist
     *
     * @param producto para añadir
     */
    public void addProducto(Producto producto) {
        productos.add(producto);
    }

    /**
     * Metodo para devolver el tamaño de la coleccion usuarios 
     * 
     * @return devuelve el numero de usuarios que tiene el arraylist
     */
    public int getNumeroUsuarios() {
        return usuarios.size();
    }

    /**
     * Metodo para devolver el tamaño de la coleccion productos 
     * 
     * @return devuelve el numero de productos que tiene el arraylist
     */
    public int getNumeroProductos() {
        return productos.size();
    }

    /**
     * Metodo que permite comprar un producto de la tienda GooglePlay.
     * 
     * @param cuenta String correo que firma la compra en googleplay.
     * @param  String que identifica la aplicacion que va a comprar.
     * 
     * @return Si el identificador indicado o el correo electrónico no existen en la tienda el método devuelve (-1) y 
     * la compra no se lleva a efecto; en caso contrario, el método devuelve el importe de la compra y la compra se 
     * realiza correctamente. Los precios de los productos de la tienda se calculan de la siguiente forma
     */
   public double comprar(String emailUsuario, String nombre)
    {
        double costeDeLaCompra = -1;
        
        Usuario usuarioABuscar = null;
        Producto productoABuscar = null;
        
        int contador = 0;
        while (contador < usuarios.size() && usuarioABuscar == null) {
            if (usuarios.get(contador).getNombreCuenta().equals(emailUsuario)) {
                usuarioABuscar = usuarios.get(contador);
            }
            contador++;
        }
       
        contador = 0;
        while (contador < productos.size() && productoABuscar == null) {
            if (productos.get(contador).getNombre().equals(nombre)) {
                productoABuscar = productos.get(contador);
            }
            contador++;
        }
        
        if (usuarioABuscar != null && productoABuscar != null) {
            costeDeLaCompra = productoABuscar.getPrecio();
            productoABuscar.vender();
        }
        
        return costeDeLaCompra;
}

}
