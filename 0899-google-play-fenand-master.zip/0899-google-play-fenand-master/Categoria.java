
/**
 * Enumeracion con las categorias de las aplicaciones
 *
 * @author (Fernando)
 * @version (29 de mayo de 2018)
 */
public enum Categoria
{
    JUEGOS("Juegos",5), 

    PRODUCTIVIDAD("Productividad",10), 

    COMUNICACIONES("Comunicaciones",2), 

    MULTIMEDIA("Multimedia",2);

    private String nombre;
    private double precioPorDescargas;

    /**
     * Constructor de la clase enum Categoria
     * 
     * @param  String para añadir el nombre de la categoria.
     */
    private Categoria(String nombre, double precioPorDescargas) {
        this.nombre = nombre;
        this.precioPorDescargas = precioPorDescargas;
    }

    /**
     * Metodo que devuelve un String con el nombre de la categoria.
     * 
     * @return El nombre de la categoria
     */
    public String getNombreCategoria(){
        return nombre;
    }
    
    /**
     * Metodo para devolver las descargas totales para calcular el precio
     * 
     * @return precioPorDescargas
     */
    public double getPrecioPorDescargas(){
    return precioPorDescargas;
    }
}
