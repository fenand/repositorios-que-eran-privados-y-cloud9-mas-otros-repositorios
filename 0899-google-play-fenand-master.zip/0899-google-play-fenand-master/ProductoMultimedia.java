
/**
 * Clase encargada de crear los productos multimedia como peliculas o libros
 *
 * @author (Fernando)
 * @version (29 de mayo de 2018)
 */
public abstract class ProductoMultimedia extends Producto
{
    private int año;
    
    /**
     * Constructor de la clase ProdudctoMultimedia
     * 
     * @param identificador
     * @param año
     */
    public ProductoMultimedia(String titulo, int año)
    {
        super(titulo);
        this.año = año;
    }

    /**
     * Metodo que devuelve el nombre de la aplicacion
     * 
     * @return nombre de la aplicacion
     */
    public String getNombre()
    {
        return super.getNombre();
    }

    /**
     * Metodo que devuelve el año del producto multimedia
     * 
     * @return el año del producto multimedia
     */
    public int getAño()
    {
        return año;
    }

}