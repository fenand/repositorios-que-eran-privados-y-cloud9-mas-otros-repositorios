
/**
 * Clase aplicacion engargada de crear las aplicaciones.
 *
 * @author (Fernando)
 * @version (29 de mayo de 2018)
 */
public class Aplicacion extends Producto
{
    private Categoria categoria;
    private double tamañoEnMB;
    private static final int DESCARGAS_PARA_SUBIR_PRECIO = 2;
    private static final double PRECIO_INICIAL_APLICACION = 0.99;

    /**
     *Constructor de la clase Aplicacion
     *
     * @param nombre
     * @param tamañoEnMB
     * @param categoria
     */
    public Aplicacion(String nombre, double tamañoEnMB, Categoria categoria)
    {
        super(nombre);
        this.categoria = categoria;
        this.tamañoEnMB = tamañoEnMB;
    }

    /**
     * metodo que devuelve el tamaño en MB
     * 
     * @return tamaño en MB
     */
    public double getTamanoEnMB()
    {
        return tamañoEnMB;
    }

    /**
     * Metodo que devuelve el nombre de la aplicacion
     * 
     * @return nombre de la aplicacion
     */
    public String getNombre()
    {
        return super.getNombre();
    }

    /**
     * Metodo que devuelve la categoria de la aplicacion
     * 
     * @return devuelve la categoria de la aplicacion
     */
    public String getCategoria()
    {
        return categoria.getNombreCategoria();
    }
    /**
     * Metodo para calcular el precio en funcion de sus descargas
     * 
     * @return precio de la aplicacion
     */
    @Override
    public double getPrecio()
    {
        double precio = PRECIO_INICIAL_APLICACION;
        if (getNumeroVecesVendido() >= DESCARGAS_PARA_SUBIR_PRECIO) {
            precio = categoria.getPrecioPorDescargas();
        }        
        return precio;
    }

}
