
/**
 * Clase encargada de crear los usuarios
 *
 * @author (Fernando)
 * @version (29 de mayo de 2018)
 */
public class Usuario
{
    private String email;

    /**
     * Constructor de la clase usuario
     * 
     * @param email del usuario
     */
    public Usuario(String email)
    {
        this.email = email;
    }

    /**
     * Metodo que devuelve el nombre del correo
     * 
     * @return string con el email
     */
    public String getNombreCuenta()
    {
        return email;
    }

}
