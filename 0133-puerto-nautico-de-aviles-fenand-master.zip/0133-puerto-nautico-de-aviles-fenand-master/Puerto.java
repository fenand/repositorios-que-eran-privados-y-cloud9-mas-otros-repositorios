import java.util.ArrayList;
/**
 * clase puerto encargada de alquilar amarres
 */
public class Puerto
{

    //array de alquileres
    private Alquiler[] amarres;
    //numero de amarres que tiene el puerto
    public static final int NUMERO_AMARRES = 4;
    /**
     * Constructor de la clase Puerto
     */
    public Puerto()
    {
        amarres = new Alquiler[4];
        for(int i = 0 ; i < NUMERO_AMARRES; i++){
            amarres[i] = null;
        }
    }

    /** 
     * El m�todo alquilarAmarre de la clase Puerto mira a ver si hay amarres libres. Si no los hay devuelve -1; 
     * en caso contrario, alquila el primer amarre libre y devuelve el coste de este alquiler.
     * 
     * @param numero de dias del alquiler
     * @param barco que quieres alquilar
     * 
     * @return -1 si no dispone de amarres libres, si dispone alquila y devuelve el coste del alquiler
     */
    public double alquilarAmarre(int numeroDias, Barco barco){
        double contadorAlquileres = -1;
        int i = 0;
        boolean libre = false;
        while(i < amarres.length && !libre){
            if(amarres[i] == null){
                amarres[i] = new Alquiler(numeroDias, barco);
                contadorAlquileres = amarres[i].getPrecio();
                libre = true;
            }
            i++;
        }

        return contadorAlquileres;
    }

    /**
     * Metodo imprime los amarres que estan alquilados y los que aun estan vacios
     * 
     * 
     */
    public void verEstadoAmarres(){
        if (amarres.length > 0){
            int contadorAmarres = 0;
            int contador = 0;
            while (contadorAmarres < NUMERO_AMARRES){
                if (contador < amarres.length){
                    System.out.println("Amarre " + (contadorAmarres) 
                        + " esta ocupado, el valor de su alquiler en este momento es = ");

                    contadorAmarres++;
                    contador++;
                }
                else{
                    System.out.println("Amarre " + (contadorAmarres) + " esta vacio");
                    contadorAmarres++;
                }
            }
        }
        else{
            for(int contadorAmarres = 0; contadorAmarres < NUMERO_AMARRES;contadorAmarres++){
                System.out.println("Amarre " + (contadorAmarres) + " esta vacio");
            }
        }
    }

    /**
     * Metodo que liquida un alquiler 
     * @return devuelve -1 en caso de no poder liquidar el amarre si o liquida devuelve el
     * precio del amarre y lo liquida
     */
    public double liquidarAlquilerAmarre(int numeroDeAmarre){  
        double aDevolver = -1;
        if(numeroDeAmarre <= NUMERO_AMARRES){
            if(amarres[numeroDeAmarre] != null){
                aDevolver = amarres[numeroDeAmarre].getPrecio();
                amarres[numeroDeAmarre] = null;
            }
        }

        return aDevolver;

    }
}

