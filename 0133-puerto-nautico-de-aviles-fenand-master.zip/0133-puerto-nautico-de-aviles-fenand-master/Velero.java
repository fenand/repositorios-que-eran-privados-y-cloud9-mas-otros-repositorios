
/**
 * Clase encargada de generar un tipo de barco en concreto un velero
 * 
 */
public class Velero extends Barco
{
    //numero de mastiles del barco
    private int numMastiles;

    /**
     * Constructor de la clase  Velero
     * 
     * @param string con la matricula del barco
     * @param distancia de metros de la eslora
     * @param a�o de fabricacion
     * @param propietario de la embarcacion
     * @param numero de mastiles que tiene el velero
     */
    public Velero(String matricula,double eslora, int ano, Persona propietario,int numMastiles)
    {
        super(matricula, eslora, ano, propietario);   
        this.numMastiles = numMastiles;
    }

    /**
     * Metodo abstracto para calcular el coeficiente de Bernua
     * 
     * @return devuelve el coeficiente de bernua
     */
    @Override
    public int getCoeficienteBernua(){
        return numMastiles ;
    }

    /**
     * Metodo para devolver las caracteristicas de los veleros
     * 
     * @return devuelve las caracteristicas de los veleros
     */
    @Override
    public String toString(){
        String aDevolver = "";
        aDevolver += super.toString() + "\n"; //toString de la clase barco
        aDevolver += "Numero de Mastiles: "+ numMastiles + "\n";
        return aDevolver;
    }

}
