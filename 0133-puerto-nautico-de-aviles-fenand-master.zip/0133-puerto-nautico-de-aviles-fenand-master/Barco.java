
/**
 * SuperClase abstracta encargada de generar barcos para realizar el alquiler
 * 
 */
public abstract class Barco
{
    //matricula del barco
    private String matricula;
    //metros de eslora del barco
    private double eslora;
    //a�o de fabricacion del barco
    private int anoFabricacion;
    //propietario del barco
    private Persona propietario;

    /**
     * Constructor de la  clase Barco
     * 
     * @param string con la matricula del barco
     * @param double con los metros de eslora
     * @param int con la fecha de fabricacion del barco
     * @param propietario del barco
     */
    public Barco(String matricula,double eslora, int ano, Persona propietario)
    {
        this.matricula = matricula;
        this.eslora = eslora;
        this.anoFabricacion = ano;
        this.propietario = propietario;
    }

    /**
     * Metodo que devuelve los metros de eslora del barco
     * 
     * @return metros de eslora
     */
    public double getEslora(){
        return eslora;
    }

    /**
     * Metodo abstracto para calcular el coeficiente de Bernua
     * 
     * @return devuelve el coeficiente de bernua
     */
    public abstract int getCoeficienteBernua();

    /**
     * Metodo para devolver las caracteristicas de los barcos
     * 
     * @return devuelve un string con los dato de los barcos
     */
    @Override
    public String toString(){
        String aDevolver = "";
        aDevolver += "Numero de Matricula: "+ matricula + "\n";
        aDevolver += "Metros de eslora: "+ eslora + "\n";
        aDevolver += "A�o de fabricacion: "+ anoFabricacion + "\n";
        aDevolver += "Propietario del la embarcacion: "+ propietario + "\n";
        return aDevolver;
    }
}
