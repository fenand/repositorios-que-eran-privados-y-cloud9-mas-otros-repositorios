
/**
 * clase encargada de alquilar amarres
 * 
 */
public class Alquiler 
{
    //precio base para calcular el alquiler
    public static final int PRECIO_BASE = 300;
    //multiplicador para la eslora 
    public static final int MULTIPLICADOR_ESLORA = 10;
    //numero de dias de alquiler
    private int numDias;
    //barcos quevas hacer el alquiler
    private Barco barco;

    /**
     * Constructor de la clase Alquiler
     * 
     * @param numero de dias del alquiler
     * @param barco que alquila el amarre
     */
    public Alquiler(int numeroDias, Barco barco)
    {
        this.numDias = numeroDias;
        this.barco = barco;
    }

    /**
     * Metodo para devolver el precio del alquiler
     * 
     * @return precio del alquiler del amarre en funcion de diversos parametros que determinan el precio
     */
    public double getPrecio(){
        double precioFinal = 0;
        precioFinal = numDias * (MULTIPLICADOR_ESLORA * barco.getEslora()) + (PRECIO_BASE * barco.getCoeficienteBernua());
        return precioFinal;
    }

    /**
     * Metodo para devolver las caracteristicas del alquiler de los barcos
     * 
     * @return devuelve las caracteristicas del alquiler de un amarre
     */
    public String toString(){
        String aDevolver = "";
        aDevolver += "Numero de dias: " + numDias + "\n";
        aDevolver += "Embarcacion: " + barco.toString()+ "\n";
        aDevolver += "Precio del alquiler: " + getPrecio() + "\n";
        //aDEvolver += 
        return aDevolver;
    }
}
