
/**
 * Clase encargada de generar embarcaciones a motor que sean yates
 */
public class Yate extends EmbarcacionAMotor
{
    //numero de camarores
    private int numeroCamarotes;

    /**
     * Constructor de la clase Yate
     * 
     * @param string con la matricula del barco
     * @param distancia en metros de la eslora del barco
     * @param a�o de creacion del barco
     * @param propietario de la embarcacion
     * @param potncia en cv del barco
     * @param numero de camarotes del barco
     */
    public Yate(String matricula,double eslora, int ano, Persona propietario,int potencia,int numeroCamarotes)
    {
        super(matricula, eslora, ano, propietario,potencia);
        this.numeroCamarotes = numeroCamarotes;
    }

    /**
     * Metodo para calcular el coeficiente de Bernua
     * 
     * @return devuelve el coeficiente de bernua
     */
    @Override
    public int getCoeficienteBernua(){

        return numeroCamarotes + super.getCoeficienteBernua();
    }

    /**
     * Metodo para devolver las caracteristicas de los veleros
     * 
     * @return devuelve las caracteristicas generales de los barcos y la del yate
     */
    @Override
    public String toString(){
        String aDevolver = "";
        aDevolver += super.toString() + "\n"; //toString de la clase embarcacionesamotor
        aDevolver += "Numero de Camarotes: "+ numeroCamarotes + "\n";

        return aDevolver;
    }

}
