
/**
 * Clase persona encargada de crear los clientes y propietarios de las embarcaciones
 */
public class Persona
{
    //nombre de la persona
    private String nombre;
    //dni de la persona
    private String dni;

    /**
     * Constructor de la clase Persona
     * 
     * @param nombre de la persona
     * @param dni de la persona
     */
    public Persona(String nombre,String dni)
    {
        this.nombre = nombre;
        this.dni = dni;
    }

    /**
     *Devuelve el dni. 
     *
     *@return devuelve el dni de la persona
     */
    public String getDni()
    {
        return dni;
    }

    /**
     * Devuelve el nombre
     * 
     * @return devuelve el nombre de la persona
     */
    public String getNombre(){
        return nombre;
    }

    /**
     * Imprime los datos por pantalla
     * 
     * @return devuelve las caracteristicas de la persona
     */
    public String toString(){
        String aDevolver = "";
        aDevolver += "Nombre de la persona: " + nombre + "\n";
        aDevolver += "DNI de la persona: " + dni + "\n";
        return aDevolver;
    }
}
