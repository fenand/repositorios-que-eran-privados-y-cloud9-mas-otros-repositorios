import java.util.ArrayList;
import java.util.Collections;
import java.util.PriorityQueue;

public class Main {

	public static void main(String[] args) {
		
		Persona p1 = new Persona("Judit B�cquer", 21);
		Persona p2 = new Persona("Javier Maroto", 30);
		Persona p3 = new Persona("Enrique Pastor", 43);
		Persona p4 = new Persona("Antonio Recio", 40);
		Persona p5 = new Persona("Lola Reynolds", 18);
		
		ArrayList <Persona> lista = new ArrayList();
		lista.add(p1);
		lista.add(p2);
		lista.add(p3);
		lista.add(p4);
		lista.add(p5);
		
		Collections.sort(lista);
		System.out.println("orden natural: "+lista);
		
		Collections.sort(lista, new MayorMenor());
		System.out.println("orden por edad mayor-menor: "+lista);
		
		Collections.sort(lista, new MenorMayor());
		System.out.println("orden por edad menor-mayor: "+lista);
	}
}
