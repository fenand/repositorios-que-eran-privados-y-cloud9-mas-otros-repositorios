public class Persona implements Comparable <Persona> {
	
	private String nombre;
	private int edad;
	
	Persona (String nombre, int edad){
		this.nombre = nombre;
		this.edad = edad;
	}
	
	@Override
	public String toString(){
		return this.nombre +" [" +this.edad +"]";
	}

	public String getNombre(){
		return this.nombre;
	}
	public int getEdad(){
		return this.edad;
	}	
	
	@Override
	public int compareTo(Persona p){
		return this.getNombre().compareTo(p.getNombre());
	}
	
}
