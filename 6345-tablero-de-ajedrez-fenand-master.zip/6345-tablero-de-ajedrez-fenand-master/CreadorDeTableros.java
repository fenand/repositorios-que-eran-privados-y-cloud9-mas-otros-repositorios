
/**
 * clase que crea tableros personalizados.
 * 
 * @author (fernando) 
 * @version (creado el 25 de mayo de 2018)
 */
public class CreadorDeTableros
{

    private static final int TAMAÑO_FILA_Y_COLUMNA = 4;
    private static final int TAMAÑO_GUIONES = 8;
    /**
     * Constructor for objects of class Tablero
     */
    public CreadorDeTableros()
    {

    }

    /**
     * Metodo encargasdo de crear el tablero segun el pametros que le pases que indica el
     * tamaño del escaque que es cada recuadro del tablero de ajedrez y tambien indica el 
     * parametro el caracter que forma ese escaque.
     * 
     * @param String con el tamaño del escaque y el caracter que lo forma ("3 %")
     * @return devuelve un string con el tablero de ajedrez
     */
    public String devolverTablero(String tamañoEscaqueYCaracter){
        String aDevolver = "";

        String[] escaque = tamañoEscaqueYCaracter.split("\\s");

        int tamañoEscaque = Integer.parseInt(escaque[0]);
        String caracter = escaque[1];
        String guion = "";
        for(int numeroGuiones = 0; numeroGuiones < TAMAÑO_GUIONES * tamañoEscaque;numeroGuiones++){
            guion += "-";
        }

        String casillaBlanca = "";
        for(int i = 0; i < tamañoEscaque ; i++){
            casillaBlanca += " ";
        }

        String casillaNegra = "";
        for(int j = 0; j < tamañoEscaque;j++){
            casillaNegra += caracter ;
        }

        aDevolver += "|" + guion + "|"+ "\n";
        for(int casilla = 0; casilla < TAMAÑO_FILA_Y_COLUMNA; casilla++){

            for(int fila1 = 0; fila1 < tamañoEscaque; fila1++){
                aDevolver += "|";
                for(int columna1 = 0 ; columna1 < TAMAÑO_FILA_Y_COLUMNA; columna1++){
                    aDevolver +=  casillaBlanca + casillaNegra ;
                }
                aDevolver += "|"+ "\n";
            }

            for(int fila2 = 0; fila2 < tamañoEscaque; fila2++){
                aDevolver += "|";
                for(int columna2 = 0 ; columna2 < TAMAÑO_FILA_Y_COLUMNA; columna2++){
                    aDevolver +=  casillaNegra + casillaBlanca ;
                }
                aDevolver +=  "|"+"\n";
            }

        }
        aDevolver += "|" + guion + "|\n";

        return aDevolver;
    }

}