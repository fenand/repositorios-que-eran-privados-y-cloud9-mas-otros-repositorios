
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * 
 * Muro de noticias de la red social
 * 
 * Lista de mensajes que deberían aparecer por pantalla 
 * cuando el usuario abre la página principal de la red social. Inicialmente, 
 * en el news feed aparecerán solo dos tipos de entradas: entradas de texto (que contendrán un texto) y 
 * entradas de foto (que contendrán una imagen y un titulo para dicha imagen).
 * 
 * @author (Fernando) 
 * @version (20/04/2018)
 */
public class EntradaConComentarios extends Entrada
{
    // Comentarios de la entrada.
    private ArrayList<String> comentarios;

    /**
     * Constructor for objects of class Entrada
     * @param autor de la entrada
     */
    public EntradaConComentarios(String autor)
    {
        super(autor);
        comentarios = new ArrayList<>();
    }

    /**
     * Anade un comentario a a la entrada.
     * @param text El comentario a anadir.
     */
    public void addComentario(String text)
    {
        comentarios.add(text);
    }
    /**
     * Metodo para devolver el arraylist de comentarios
     * @return Devuelve una cadena con todos los comentarios.
     */
    private String getComentarios(){
        // Comprobamos si hay comentarios. Si hay los mostramos, si no, mostramos un mensaje indicandolo.
        String aDevolver ="";
        if (comentarios.size() == 0)         {
            aDevolver += "No hay comentarios\n";
        }
        else {
            aDevolver += "Comentarios: \n";
            for(String comentarioActual : comentarios){
                aDevolver += comentarioActual + "\n";
            }
        }
        return aDevolver;
    }

    /**
     * Devuelve una cadena con toda la informacion de la entrada.
     * @return Devuelve una cadena con toda la informacion de la entrada.
     */
    @Override
    public String toString()
    {
        String aDevolver = "";
        aDevolver += super.toString()+ "\n";
        aDevolver += getComentarios() ;

        return aDevolver;
    }

}