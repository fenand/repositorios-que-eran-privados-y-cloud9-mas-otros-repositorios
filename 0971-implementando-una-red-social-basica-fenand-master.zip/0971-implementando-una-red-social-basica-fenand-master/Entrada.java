
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * 
 * Muro de noticias de la red social
 * 
 * Lista de mensajes que deberían aparecer por pantalla 
 * cuando el usuario abre la página principal de la red social. Inicialmente, 
 * en el news feed aparecerán solo dos tipos de entradas: entradas de texto (que contendrán un texto) y 
 * entradas de foto (que contendrán una imagen y un titulo para dicha imagen).
 * 
 * @author (Fernando) 
 * @version (20/04/2018)
 */
public class Entrada
{
    //usuario de la entrada
    private String usuario;
    // Numero de 'me gusta' de la entrada.
    private int cantidadMeGusta;
    // Fecha de publicacion de la entrada.
    private LocalDateTime momentoPublicacion;

    /**
     * Constructor for objects of class Entrada
     * @param autor de la entrada
     */
    public Entrada(String autor)
    {
        usuario = autor; 
        momentoPublicacion = LocalDateTime.now();
        cantidadMeGusta = 0;
    }

    /**
     * Anade un 'me gusta' a la entrada.
     */
    public void meGusta()
    {
        cantidadMeGusta += 1;
    }

    /**
     * Devuelve la fecha de publicacion.
     * @return Devuelve la fecha de publicacion.
     */
    public LocalDateTime getMomentoPublicacion()
    {
        return momentoPublicacion;
    }

    /**
     * Devuelve el contenido del autor de la publicacion
     * @return autor de la entrada
     */
    public String getUsuario(){
        return usuario;

    }

    /**
     * Devuelve la cantidad de me gusta de la publicacion
     * @return cantidad de me gusta
     */
    public int getMeGusta(){
        return cantidadMeGusta;
    }

    /**
     * Metodo para imprimir toda la informacion del muro
     */
    public void mostrar(){

    }

    /**
     * Metodo para devolver un string con las caracteristicas de las entradas
     * @return Devuelve una cadena con toda la informacion de la entrada.
     */
    @Override
    public String toString()
    {
        String aDevolver = "";
        aDevolver += "Usuario: " + getUsuario() + "\n";
        aDevolver += "Likes: " + getMeGusta() + "\n";        
        // Calculamos el numero de segundos que han pasado desde la fecha de publicacion.
        long numeroSegundos = getMomentoPublicacion().until(LocalDateTime.now(), ChronoUnit.SECONDS);
        aDevolver += "Escrito hace ";

        // Comprobamos si debemos expresar el tiempo en segundos o minutos.
        if(numeroSegundos > 59){
            aDevolver += numeroSegundos / 60 + " minutos";
        }
        else {
            aDevolver += numeroSegundos + " segundos";
        }
        return aDevolver;
    }

    /**
     * Muestra por pantalla los datos exclusivos de la clase.
     */
    public void mostrarDatosExclusivos()
    {                
    }    


}