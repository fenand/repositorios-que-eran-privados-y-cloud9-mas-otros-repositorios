import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Una entrada con imagenes.
 * 
 * Pertenece a la aplicacion '0971 - red social'.
 * 
 * Una entrada es un contenido que el usuario comparte en su muro con la comunidad.
 * Las entradas con imagenes se crean a partir de un autor, un titulo
 * para la imagen y la url de la imagen.
 * 
 * @author (Fernando) 
 * @version (20/04/2018)
 */
public class EntradaFoto extends EntradaConComentarios
{
    // URL de la imagen.
    private String urlImagen;
    //Título de la entrada.
    private String titulo;

    /**
     * Constructor - Construye entradas a partir de un autor, el titulo de la imagen y su URL.
     * Las entradas se crean sin ningun ' me gusta'.
     * La fecha de publicacion coincide con el momento en el que se crea la entrada.
     * @param autor Autor de la entrada.
     * @param titulo Titulo de la imagen.
     * @param url de la imagen
     */
    public EntradaFoto  ( String url,String titulo,String autor)
    {
        super(autor);
        urlImagen = url;
        this.titulo = titulo;

    }

    /**
     * Devuelve el URL de la imagen.
     * @return Devuelve el URL de la imagen.
     */
    public String getUrlImagenes()
    {
        
        String ubicacionImg = "<img src=" + urlImagen + ">";
        return ubicacionImg;
    }
    

    /**
     * Devuelve el titulo de la imagen.
     * @return Devuelve el titulo de la imagen.
     */
    public String getTituloImagen()
    {
        return titulo;
    }

    /**
     * Devuelve una cadena con toda la informacion de la entrada.
     * @return Devuelve una cadena con toda la informacion de la entrada.
     */
    @Override
    public String toString()
    {
        String aDevolver = "";  
        aDevolver += "<h2> Entrada De Foto </h2>" +  "\n";
        aDevolver += "Titulo: " + titulo + "\n";
        aDevolver += super.toString() ;
        aDevolver += getUrlImagenes() + "\n";
        aDevolver+= "<br><br>";

        return aDevolver;
    }

    /**
     * Metodo para mostrar mostrarDatosExclusivos
     */
    @Override
    public void mostrarDatosExclusivos(){
        System.out.println("Titulo: " + titulo + "\n");
        System.out.println("Url: " + getUrlImagenes() + "\n");

    }

    /**
     * metodo que imprime por pantalla las entradas
     */
    @Override
    public void mostrar(){
        System.out.println(this);

    }
}