import java.util.ArrayList;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.io.FileNotFoundException;
import java.io.IOException;


/**
 * 
 * Muro de noticias de la red social
 * 
 * Lista de mensajes que deberían aparecer por pantalla 
 * cuando el usuario abre la página principal de la red social. Inicialmente, 
 * en el news feed aparecerán solo dos tipos de entradas: entradas de texto (que contendrán un texto) y 
 * entradas de foto (que contendrán una imagen y un titulo para dicha imagen).
 * 
 * @author (Fernando) 
 * @version (16/04/2018)
 */
public class Muro 
{
    private ArrayList<Entrada> entradas;

    /**
     * Constructor for objects of class Muro
     */
    public Muro()
    {
        entradas = new ArrayList<>();
    }

    /**
     * metodo para añadir entradas
     */
    public void addEntrada(Entrada entrada){
        entradas.add(entrada);
    }

    /**
     * metodo para pasar a string todas las caracteristicas del muro
     */
    @Override
    public String toString(){
        String entradasMuro = "";
        if(!entradas.isEmpty()){

            for(Entrada entrada : entradas){
                entradasMuro += " Entrada : " +  entrada + "\n";

            }
        }
        else{
            System.out.println("El muro no tiene entradas ");
        }

        return entradasMuro + "\n ";

    }

    /**
     * Muestra el muro por la terminal de texto.
     */
    public void mostrarMuro() 
    {
        for (Entrada entrada : entradas){
            entrada.mostrar();
            System.out.println();
        }
    }

    /**
     * Metodo para mostrar los datos exclusivos de las entradas que seleccionemos por 
     * por parametro
     * @param String con el tipo de entrada que queremos los datos
     */
    public void mostrarDatosExclusivosEntradasFiltradas(String tipoEntrada)
    {
        for (Entrada entrada : entradas) {
            if (entrada.getClass().getSimpleName().equals(tipoEntrada) || tipoEntrada == null) {
                entrada.mostrarDatosExclusivos();
            }
        }
    }

    /**
     * Metodo para añadir a una pagina html la informacion de las entradas
     */
    public void mostrarMuroEnNavegador(){
        // Obtenemos una referencia a una ruta donde estará el archivo
        Path rutaArchivo = Paths.get("datos.html");

        // Abrimos el archivo, escribimos en él y lo cerramos. Si se produce un
        // error de cualquier tipo (por ejempo, que el archivo exista y no tengamos
        // permisos de escritura) se aborta la operación y aparece el error en
        // la terminal
        String direccion = "file:///C:/Users/Fernando/Desktop/red-social/datos.html";
        try  
        {
            BufferedWriter archivo = Files.newBufferedWriter(rutaArchivo);
            archivo.write("<html>");
            archivo.write("<head>");
            archivo.write("<meta charset="+"utf-8"+"/>");
            archivo.write("<title>Red Social</title>");
            archivo.write("<style type="+"text/css"+">");
            archivo.write(" body { background-color: #3094d8;  font-size: 200%}");
            archivo.write("h1 {color: black; font-weight : bold;text-align: center;}");
            archivo.write("h2 {color: black; font-weight : bold;text-align: center; border: 5px solid black;}");
            archivo.write("p { font-weight : bold;font-style : italic;  border: 4px solid powderblue; padding: 15px; color: black; font-size: 100%;text-align: center;}");
            archivo.write("img {border-radius: 10%; width: 50%; height: 50%;}");
            
            archivo.write("</style>");
            archivo.write(" <body>");
            archivo.write(" <h1>Red Social</h1>");
            archivo.write("<br><br>");

            for (Entrada entrada : entradas) {
                String[] lineas = entrada.toString().split("\n");

                for(int i = 0; i < lineas.length; i++){
                    archivo.write("<p>"+ lineas[i] + "\n" +"</p>");

                }
            }

            archivo.write(" </body>");
            archivo.write("</html>");
            
            
            Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + direccion);
            archivo.close();
        }
        catch (IOException excepcion) {
            // Mostramos por pantalla la excepción que se ha producido
            System.out.println(excepcion.toString());

        }
    }

    public void borrarPaginaWeb(){
        Path rutaArchivo = Paths.get("datos.html");
        
        try  
        {
            BufferedWriter archivo = Files.newBufferedWriter(rutaArchivo);
            archivo.write("<html>");
            archivo.write("<head>");
            archivo.write("<meta charset="+"utf-8"+"/>");
            archivo.write("<title>Red Social</title>");
            archivo.write("<style type="+"text/css"+">");
            archivo.write(" body { background-color: #3094d8;  font-size: 200%}");
            archivo.write("h1 {color: black; font-weight : bold;}");
            archivo.write("p { font-weight : bold;font-style : italic;border: 2px solid powderblue; padding: 20px; color: black; font-size: 100%;text-align: center;}");
            archivo.write("</style>");
            archivo.write(" <body>");
            archivo.write(" <h1><center>Red Social</center></h1>");
            archivo.write("<br><br>");
            archivo.write(" </body>");
            archivo.write("</html>");

            archivo.close();

        }
        catch (IOException excepcion) {
            // Mostramos por pantalla la excepción que se ha producido
            System.out.println(excepcion.toString());
        }

    }

    
}
