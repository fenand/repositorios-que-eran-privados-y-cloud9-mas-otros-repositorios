

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class MuroTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class MuroTest
{
    private Muro muro1;
    private EntradaTexto entradaT1;
    private EntradaFoto entradaF1;
    private EntradaFoto entradaF2;
    private EntradaEvento entradaE1;
    private Entrada entrada1;

    
    
    
    
    

    
    

    /**
     * Default constructor for test class MuroTest
     */
    public MuroTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        muro1 = new Muro();
        entradaT1 = new EntradaTexto("De camino a canarias", "Fernando");
        entradaF1 = new EntradaFoto("http://blog.muchoviaje.com/wp-content/uploads/2017/04/Canarias-3.jpg", "Teide", "Fernando");
        entradaF2 = new EntradaFoto("http://blog.muchoviaje.com/wp-content/uploads/2017/04/Canarias-5.jpg", "Canarias", "Fernando");
        entradaE1 = new EntradaEvento(" pasandolo bien en el Teide", "Fernando");
        muro1.addEntrada(entradaF1);
        muro1.borrarPaginaWeb();
        muro1.borrarPaginaWeb();
        muro1.addEntrada(entradaF2);
        muro1.addEntrada(entradaE1);
        muro1.addEntrada(entradaT1);
        muro1.mostrarMuroEnNavegador();
        entrada1 = new Entrada("Fernando");
        entrada1.meGusta();
        entrada1.getMeGusta();
        entrada1.getMeGusta();
        muro1.mostrarMuroEnNavegador();
        muro1.mostrarMuroEnNavegador();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
