import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;


/**
 * 
 * Muro de noticias de la red social
 * 
 * clase para crear entradas de eventos en el muro
 * 
 * @author (Fernando) 
 * @version (20/04/2018)
 */
public class EntradaEvento extends Entrada
{
    //evento del grupo
    private String evento;
    /**
     * Constructor for objects of class EntradaEvento
     * @param evento del usuario
     * @param usuario del evento
     */
    public EntradaEvento(String eventoUsuario,String autor)
    {
        super(autor);
        this.evento = eventoUsuario;
    }

    /**
     * Devuelve el contenido de la entrada.
     * @return Devuelve el contenido de la entrada.
     */
    public String getEvento()
    {
        return evento;
    }

    /**
     * Devuelve una cadena con toda la informacion de la entrada.
     * @return Devuelve una cadena con toda la informacion de la entrada.
     */
    @Override
    public String toString()
    {
        String aDevolver = "";
        aDevolver += "<h2> Entrada De Evento </h2>" +  "\n"+ super.toString() + "\n";
        aDevolver += "Evento: " + evento + "\n";
        aDevolver+= "<br><br>";
        return aDevolver;
    }

    /**
     * Metodo para mostrar mostrarDatosExclusivos
     */
    @Override
    public void mostrarDatosExclusivos(){
        System.out.println("Evento: " + evento);

    }
    /**
     * metodo que imprime por pantalla las entradas
     */
    @Override
    public void mostrar(){
        System.out.println(this);

    }
}
