
/**
 * Clase persona de la cola de correos
 *
 * @author (Fernando)
 * @version (15/06/2018)
 */
public class Persona {

    private String nombre;
    private Persona personaSiguiente;

    /**
     * Constructor de la clase Persona
     *
     * @param nombre
     */
    public Persona(String nombre) {
        this.nombre = nombre;
        personaSiguiente = null;
    }

    /**
     * Metodo getter del nombre de la persona
     *
     * @return nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Metodo Getter de la persona siguiente de la cola
     *
     * @return persona
     */
    public Persona getPersonaSiguiente() {
        return personaSiguiente;
    }

    /**
     * setter para a�adir personas
     * @param personaSiguiente
     */
    public void setPersonaSiguiente(Persona personaSiguiente) {
        this.personaSiguiente = personaSiguiente;
    }

}
