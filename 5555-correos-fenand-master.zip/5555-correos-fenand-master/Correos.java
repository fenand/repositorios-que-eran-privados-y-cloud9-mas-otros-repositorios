
/**
 * clase correos
 *
 * @author (Fernando)
 * @version (15/06/2018)
 */
public class Correos {

    private Persona primeraPersona;
    private int tamano;

    /**
     * Constructor for objects of class Correos
     */
    public Correos() {
        primeraPersona = null;
        tamano = 0;
    }

    /**
     * getter numero de personas
     * @return int tama�o fila
     */
    public int getNumeroPersonasEnLaCola() {
        return tamano;
    }

    /**
     * meter la primera persona
     * @param nombrePersona
     */
    public void llegaPersona(String nombrePersona) {

        Persona persona = new Persona(nombrePersona);

        // if(estaLaColaVacia() ){
        // primeraPersona = persona;
        // }
        // else{
        //Persona auxiliar = primeraPersona;
        while (estaLaColaVacia()) {
            primeraPersona = persona;
            persona.setPersonaSiguiente(persona);
        }
        //}
        tamano++;
    }

    /**
     * metodo para quitar la ultima persona 
     */
    public void ultimaPersonaSeVa() {

        Persona auxiliarBorrar = primeraPersona;

        if (auxiliarBorrar.getPersonaSiguiente() == null) {
            if (estaLaColaVacia()) {
                auxiliarBorrar = primeraPersona;
                while (auxiliarBorrar.getPersonaSiguiente().getPersonaSiguiente() != null) {
                    auxiliarBorrar = auxiliarBorrar.getPersonaSiguiente();
                }
                auxiliarBorrar.setPersonaSiguiente(null);
            }
        }

    }

    /**
     * metodo para quitar a la primera persona
     */
    public void despacharALaPrimeraPersona() {

        if (tamano <= 0) {
            System.out.println("La Cola Esta Vacia");
        } else {
            primeraPersona = primeraPersona.getPersonaSiguiente();
        }
        tamano--;
    }

    /**
     * Metodo que devuelve true si la cola esta vacia y false si tiene personas
     *
     * @return boolean true o false en funcion de si la cola esta vacia o no
     */
    public boolean estaLaColaVacia() {
        boolean aDevolver = false;
        if (primeraPersona == null) {
            aDevolver = true;
        }
        return aDevolver;
    }

    /**
     * getter que devuele la primera persona de la cola
     * @return string con la persona
     */
    public String getPrimeraPersonaDeLaCola() {
        String primeraPersonaString = "";

        if (!estaLaColaVacia()) {
            primeraPersonaString = primeraPersona.getNombre();
        }
        System.out.println(primeraPersonaString);
        return primeraPersonaString;
    }

    /**
     * getter con el listado de personas de la cola
     * @return string con las personas
     */ 
    public String getListadoPersonasEnCola() {
        int posicion = 1;
        String stringPosicion = "" + posicion;
        String aDevolver = "Cola vacia";
        if (estaLaColaVacia()) {
            Persona copiaPersonas = primeraPersona;
            while (copiaPersonas != null) {
                System.out.println(stringPosicion + "-");
                posicion++;
            }
        }
        return aDevolver;
    }
}
