
/**
 * Write a description of class D_Nave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class D_Nave extends Disparo
{
    
    public D_Nave(int valorX,int valorY)
    {
        super(valorX,valorY);
        velocidadEnY=-2;
    }

}
