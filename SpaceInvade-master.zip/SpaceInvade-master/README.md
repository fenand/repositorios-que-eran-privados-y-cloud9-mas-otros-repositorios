# Space Invade Borja
Es una space invade classico simple XD.
## Controles
* [Derecha] - Mueve la nave hacia la derecha.
* [Izquierda] - Mueve la nave hacia la izquierda.
* [Barra Espaciadora] - Dispara.
* [P] - Pausa.