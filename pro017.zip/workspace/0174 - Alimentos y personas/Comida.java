public class Comida
{
    private String nombreComida;
    private int calorias;
    
    /**
     * Constructor de la clase
     * @param nombreComida El nombre de la comida
     * @param calorias Las calorias de la comida
     */
    public Comida(String nombreComida, int calorias)
    {
        this.nombreComida = nombreComida;
        this.calorias = calorias;
        
    }
    
    /**
     * Devuelve las calorias de esta comida
     * @return Las calorias de la comida
     */
    public int getCalorias()
    {
        return calorias;   
    }
    
    
    
    /**
     * Devuelve el nombre de la comida
     * @return El nombre de la comida
     */
    public String getNombre() 
    {
        return nombreComida;
    }
    
    
}