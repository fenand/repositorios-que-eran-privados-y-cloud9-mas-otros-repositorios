/**
 * Esta clase simula la ingesta de alimentos de una persona.
 */
public class Persona
{
    private String nombre;
    private boolean esMujer;
    private int edad;
    private int peso;
    private int altura;
    private int caloriasIngeridas;
    private int metabolismoBasal;
    private Comida comidaMasCaloricaIngerida;

    /**
     * Constructor de la clase
     * @param nombre El nombre de la persona
     * @param esMujer Verdadero si es mujer, falso si es hombre
     * @param edad La edad en años
     * @param peso El peso en kilogramos
     * @param altura La altura en centimetros
     */
    public Persona(String nombre, boolean esMujer, int edad, int peso, int altura)
    {
        this.nombre = nombre;
        this.esMujer = esMujer;
        this.edad = edad;
        this.peso = peso;
        this.altura = altura;
        caloriasIngeridas = 0;
        metabolismoBasal = (10 * peso) + (6 * altura) + (5 * edad);
        metabolismoBasal += ((esMujer) ? -161 : 5);
        comidaMasCaloricaIngerida = null;
    }
    
    /**
     * Metodo que da de comer e informa por terminal si la persona no come
     * @param comida La comida a ingerir
     * @return -1 si no come y si come devuelve calorias del alimento
     */
    public int comer(Comida comida)
    {
        int caloriasADevolver = -1;
        if (metabolismoBasal >= caloriasIngeridas) {
            //Come
            caloriasIngeridas += comida.getCalorias();
            caloriasADevolver = comida.getCalorias();
            if(comidaMasCaloricaIngerida != null) {
                //Ya habia comido cosas
                if(comida.getCalorias() >= comidaMasCaloricaIngerida.getCalorias()) {
                    comidaMasCaloricaIngerida = comida;
                }
            }
            else {
                //No habia comido nada todavia
                comidaMasCaloricaIngerida = comida;
            }
        } 
        else {
            //No come
            System.out.println("Estoy lleno, paso de comer más!!!");
        }
        return caloriasADevolver;
    }
    
    
    /**
     * Devuelve las calorias ingeridas por la persona
     * @return El número de calorias ingeridas
     */
    public int getCaloriasIngeridas() 
    {
        return caloriasIngeridas;
    }
    
    
    /**
     * Nos permite preguntarle cosas a la persona
     * @param pregunta Lo que le queremos preguntas
     */
    public String contestar(String pregunta) 
    {
        String respuesta = "";
        if (caloriasIngeridas > metabolismoBasal || pregunta.toLowerCase().contains(nombre.toLowerCase())) {
            respuesta = pregunta.toUpperCase();
        } 
        else {
            if(pregunta.length() % 3 == 0){
                respuesta = "SI";
            }
            else {
                respuesta = "NO";
            }
        }
        System.out.println(respuesta);
        return respuesta;
    }
    
    /**
     * Devuelve el nombre de la comida más calorica consumida por la persona
     * @return El nombre del aliment más calorico consumido hasta ahora
     */
    public String getAlimentoMasCaloricoConsumido()
    {
        String nombreComidaMasCalorica = null;
        if(comidaMasCaloricaIngerida == null)
        {
            System.out.println("no he comido nada");
        }
        else {
            nombreComidaMasCalorica = comidaMasCaloricaIngerida.getNombre();
            System.out.println(nombreComidaMasCalorica);
        }
        return nombreComidaMasCalorica;
    }

}



















