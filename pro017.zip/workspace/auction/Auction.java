import java.util.ArrayList;

/**
 * A simple model of an auction.
 * The auction maintains a list of lots of arbitrary length.
 *
 * @author David J. Barnes and Michael Kölling.
 * @version 2011.07.31
 */
public class Auction
{
    // The list of Lots in this auction.
    private ArrayList<Lot> lots;
    // The number that will be given to the next lot entered
    // into this auction.
    private int nextLotNumber;

    /**
     * Create a new auction.
     */
    public Auction()
    {
        lots = new ArrayList<Lot>();
        nextLotNumber = 1;
    }

    /**
     * Enter a new lot into the auction.
     * @param description A description of the lot.
     */
    public void enterLot(String description)
    {
        lots.add(new Lot(nextLotNumber, description));
        nextLotNumber++;
    }

    /**
     * Show the full list of lots in this auction.
     */
    public void showLots()
    {
        for(Lot lot : lots) {
            System.out.println(lot.toString());
        }
    }
    
    /**
     * Make a bid for a lot.
     * A message is printed indicating whether the bid is
     * successful or not.
     * 
     * @param lotNumber The lot being bid for.
     * @param bidder The person bidding for the lot.
     * @param value  The value of the bid.
     */
    public void makeABid(int lotNumber, Person bidder, long value)
    {
        Lot selectedLot = getLot(lotNumber);
        if(selectedLot != null) {
            boolean successful = selectedLot.bidFor(new Bid(bidder, value));
            if(successful) {
                System.out.println("The bid for lot number " +
                                   lotNumber + " was successful.");
            }
            else {
                // Report which bid is higher.
                System.out.println("Lot number: " + lotNumber +
                                   " already has a bid of: " +
                                   selectedLot.getHighestBid().getValue());
            }
        }
    }

    /**
     * Return the lot with the given number. Return null
     * if a lot with this number does not exist.
     * @param lotNumber The number of the lot to return.
     */
    public Lot getLot(int lotNumber)
    {
        if((lotNumber >= 1) && (lotNumber < nextLotNumber)) {

            Lot selectedLot = null;
            int contador = 0;
            while(contador < lots.size() && selectedLot == null)  {
                Lot lotActual = lots.get(contador);
                if (lotActual.getNumber() == lotNumber){
                    selectedLot = lotActual;  
                }
                contador++
            }
            return selectedLot;
        }
        else {
            System.out.println("Lot number: " + lotNumber +
                               " does not exist.");
            return null;
        }
    }
    
    
    /**
     * Muestra los detalles de todos los lotes vendidos (nombre de la 
     * persoo la puja y valor). Para los no vendidos, debe aparecer
     * mensaje de "no vendido"
     */
    public void close() 
    {
        for(Lot lote : lots) {
            if(lote.getHighestBid() != null){
                System.out.println(lote.getDescription() + ": " + 
                                   lote.getHighestBid().getBidder().getName() + " (" +
                                   lote.getHighestBid().getValue() + ")");
            }
            else {
                 System.out.println(lote.getDescription() + se": NO tiene pujas");
            }
        }
    }
    
    
    /**
     * Devuelve los lotes no vendidos
     */
    public ArrayList<Lot> getUnsold()
    {
        ArrayList<Lot> aDevolver = new ArrayList<Lot>();
        
        for(Lot lote : lots) {
            if(lote.getHighestBid() == null){
                aDevolver.add(lote);
            }
        }
        
        return aDevolver;
    }
    
    
    /**
     * Elimina el lote con el numero de lote especificado y lo devuelve. Si no
     * hay tal lote no hace nada y devuelve null
     */ 
    public Lot removeLot(int number) 
    {
        Lot loteEliminado = getLot(number);
        lots.remove(loteEliminado);
        return loteEliminado;
        
        
    }
    
    
    
    
}
