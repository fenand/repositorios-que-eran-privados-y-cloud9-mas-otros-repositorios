public class Test {
    
  public static void main(String[] args) {
    
    // Pruebas sobre la clase FechaYHora...
    FechaYHora a = new FechaYHora();
    System.out.println(a.getFechaYHora());
    a.fijarFechaYHora(30,3,11,23,59);
    System.out.println(a.getFechaYHora());
    a.avanzar();
    System.out.println(a.getFechaYHora());
    a.fijarFechaYHora(30,12,45,23,59);
    System.out.println(a.getFechaYHora());  
    a.avanzar();
    System.out.println(a.getFechaYHora());
  }
  
}  