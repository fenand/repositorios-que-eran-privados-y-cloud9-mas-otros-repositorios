class FechaYHora
{
    private CalendarioBasico calendario;
    private ClockDisplay reloj;
    
    public FechaYHora()
    {
        calendario = new CalendarioBasico();
        reloj = new ClockDisplay();
    }
    
    public String getFechaYHora()
    {
       return calendario.obtenerFecha() + " " + reloj.getTime();
    }
    
    public void fijarFechaYHora(int day, int month, int year, int hours, int minutes)
    {
        calendario.fijarFecha(day,month,year);
        reloj.setTime(hours, minutes);
    }
    
    public void avanzar()
    {
        reloj.timeTick();
        if(reloj.getTime().equals("00:00")) {
            calendario.avanzarFecha();
        }
    }
    
  
}