import java.util.HashMap;

/**
 * This class is part of the "World of Zuul" application. 
 * "World of Zuul" is a very simple, text based adventure game.  
 * 
 * This class holds an enumeration of all command words known to the game.
 * It is used to recognise commands as they are typed in.
 *
 * @author  Michael Kölling and David J. Barnes
 * @version 2011.07.31
 */

public class CommandWords
{   
    // Lista de comandos validos.
    private HashMap<String, CommandWord> validCommands;
    
    /**
     * Constructor - initialise the command words.
     */
    public CommandWords()
    {
        validCommands = new HashMap<>();
        for (CommandWord comandoActual : CommandWord.values()) {
            if (comandoActual != CommandWord.UNKNOWN) {
                validCommands.put(comandoActual.getPalabraComando(), comandoActual);                
            }
        }
        
        
    }

    /**
     * Check whether a given String is a valid command word. 
     * @return true if a given string is a valid command,
     * false if it isn't.
     */
    public boolean isCommand(String aString)
    {
        return validCommands.containsKey(aString);
    }

    /**
     * Imprime por pantalla todos los comandos validos.
     */
    public String getCommandList()
    {
        String comandos = "";
        for(String comands : validCommands.keySet()){
            comandos = comands + " ";        
        }

        return comandos;
    }
    
    /**
     * Return the CommandWord associated with a word.
     * @param commandWord The word to look up (as a string, like "go" o "look").
     * @return The CommandWord corresponding to the String commandWord (like GO or LOOK), or UNKNOWN
     *         if it is not a valid command word.
     */
    public CommandWord getCommandWord(String commandWord)
    {
        CommandWord palabra = CommandWord.UNKNOWN;
             
        for (String command : validCommands.keySet()) {
            if (commandWord.equals(command)){
                palabra = validCommands.get(command);
            }
        }
        return palabra;
    
    }
}
