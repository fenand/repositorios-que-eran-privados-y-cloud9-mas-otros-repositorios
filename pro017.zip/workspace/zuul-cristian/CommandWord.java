/**
 * Comandos reconocidos por nuestra aplicacion.
 * 
 * Pertenece al proyecto 'zuul-cristian'
 * 
 * @author 2017/2018_DAM1
 * @version 2018/04/13
 */
public enum CommandWord {
    GO("go"), QUIT("quit"), HELP("help"), LOOK("look"), EAT("eat"), 
    BACK("back"), TAKE("take"), DROP("drop"), ITEMS("items"), UNKNOWN("");
    
    private String palabraComando;
    
    private CommandWord(String palabraAsociada)
    {
        palabraComando = palabraAsociada;
    }
    
    public String getPalabraComando() {
        return palabraComando;
    }
    
    
}