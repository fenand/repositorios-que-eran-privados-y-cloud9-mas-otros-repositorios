import java.util.Scanner;
import java.util.ArrayList;

class Main
{   
    public static void main(String[] args){
        calcularNumeroDePizzas();
    }

    public static void calcularNumeroDePizzas() 
    {     
        Scanner entradaDatos = new Scanner(System.in);
        String entradaDelUltimoDatoPorTeclado = "";
        String pedidosDePizzas = "";
        while (!entradaDelUltimoDatoPorTeclado.equals("#")){ 
            entradaDelUltimoDatoPorTeclado = entradaDatos.nextLine();
            pedidosDePizzas += entradaDelUltimoDatoPorTeclado + "\n";
        }
        String[] pedidosQueTenemosQueHacerDePizzas = pedidosDePizzas.split("\n"); 
        int contadorPedidos = 0;
        double cantidadPorciones = 0;
        ArrayList<Integer> pizzasPorPedido = new ArrayList<>(); 
        for (int i = 2; contadorPedidos < Integer.parseInt(pedidosQueTenemosQueHacerDePizzas[0]); i += 2 ){

            String[] pedido = pedidosQueTenemosQueHacerDePizzas[i].split(" ");

            for (int j = 0; j < pedido.length; j++){
                cantidadPorciones += Integer.parseInt(pedido[j]);
            }

            contadorPedidos++;            
            pizzasPorPedido.add((int)Math.ceil(cantidadPorciones / 8)); 
            cantidadPorciones = 0; 
        }
        int contadorCasos = 1;
        for(Integer casos : pizzasPorPedido){
            System.out.println("Caso #" + (contadorCasos) + ": " + pizzasPorPedido.get(contadorCasos - 1));
            contadorCasos++;
        }
    }
}
